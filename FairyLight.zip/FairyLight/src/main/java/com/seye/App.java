package com.seye;

import com.seye.controllers.MainController;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {

        MainController d = new MainController();
        d.runMainMenu();

    }
}
