package com.seye;

public class Utilities {

    public enum Colors {
        RED, GREEN, WHITE;
    }

    public enum Status {
        ON, OFF;
    }

}
